<?php

echo "Digite um número: \n";
$numero = (float) fgets(STDIN);
echo "O número é: $numero\n";
